# BY YOURS TRULY AMANTE STEEL
#    M
#    V

import asyncio
import pygame
import sys

pygame.init()

# =====================
# SETTINGS
# =====================
WIDTH, HEIGHT = 1280, 720
FPS = 60

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mini Doomspire")
clock = pygame.time.Clock()

font = pygame.font.SysFont(None, 40)
controls_font = pygame.font.SysFont(None, 28)  # smaller so the help line fits at 1280 wide

# =====================
# GAME STATES
# =====================
MENU = "menu"
PLAYING = "playing"
GAME_OVER = "game_over"

game_state = MENU

# =====================
# PLAYER CLASS BRO
# =====================
class Player:
    def __init__(self, x, y, color, controls):
        self.rect = pygame.Rect(x, y, 50, 70)
        self.color = color
        self.controls = controls

        self.speed = 5
        self.health = 100
        self.attack_timer = 0


        self.i_frame = 0          # Invincibility frame timer
        self.dodge_cooldown = 0   # Cooldown until next allowed dodge

    def update(self, keys):
        if keys[self.controls["left"]]:
            self.rect.x -= self.speed

        if keys[self.controls["right"]]:
            self.rect.x += self.speed

        if keys[self.controls["up"]]:
            self.rect.y -= self.speed

        if keys[self.controls["down"]]:
            self.rect.y += self.speed

        self.rect.clamp_ip(screen.get_rect())

        # Update cooldown timers
        if self.attack_timer > 0:
            self.attack_timer -= 1

        if self.i_frame > 0:
            self.i_frame -= 1

        if self.dodge_cooldown > 0:
            self.dodge_cooldown -= 1

    def draw(self):
        pygame.draw.rect(screen, self.color, self.rect)

        pygame.draw.rect(screen, (255,0,0),
                         (self.rect.x, self.rect.y-12, 50, 6))

        # Health bar turns yellow if the player is currently dodging
        health_color = (255, 255, 0) if self.i_frame > 0 else (0, 255, 0)

        pygame.draw.rect(screen, health_color,
                         (self.rect.x, self.rect.y-12,
                          max(0, self.health/2), 6))

# =====================
# ROCKET GO BOOM BOOM
# =====================
class Rocket:
    def __init__(self, x, y, vx, owner):
        self.rect = pygame.Rect(x, y, 15, 15)
        self.vx = vx
        self.owner = owner

    def update(self):
        self.rect.x += self.vx

    def draw(self):
        pygame.draw.rect(screen, (255, 255, 0), self.rect)

# =====================
# PLAYERS
# =====================
p1 = Player(
    100,
    250,
    (0, 120, 255),
    {
        "left": pygame.K_a,
        "right": pygame.K_d,
        "up": pygame.K_w,
        "down": pygame.K_s,
        "dodge": pygame.K_e # Player 1 Dodge key
    }
)

p2 = Player(
    1080,
    250,
    (255, 80, 80),
    {
        "left": pygame.K_LEFT,
        "right": pygame.K_RIGHT,
        "up": pygame.K_UP,
        "down": pygame.K_DOWN,
        "dodge": pygame.K_KP0 # P2 Dodge Key (Numpad 0)
    }
)

rockets = []
winner = ""

# =====================
# RESET
# =====================
def reset_game():
    global rockets

    rockets.clear()

    p1.rect.topleft = (100,250)
    p2.rect.topleft = (1080,250)

    p1.health = 100
    p2.health = 100

    p1.i_frame = 0
    p2.i_frame = 0
    p1.dodge_cooldown = 0
    p2.dodge_cooldown = 0

# =====================
# MAIN LOOP
# =====================
async def main():
    global game_state, winner

    running = True
    while running:

        dt = clock.tick(FPS)

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            if game_state == MENU:

                if event.type == pygame.KEYDOWN:
                    game_state = PLAYING
                    reset_game()

            elif game_state == PLAYING:

                if event.type == pygame.KEYDOWN:

                    # P1 sword
                    if event.key == pygame.K_f:
                        if p1.attack_timer <= 0:
                            sword = pygame.Rect(
                                p1.rect.right,
                                p1.rect.y,
                                40,
                                p1.rect.height
                            )

                            # Check collision AND if P2 is not currently in i-frames
                            if sword.colliderect(p2.rect) and p2.i_frame == 0:
                                p2.health -= 20

                            p1.attack_timer = 20

                    # Player2 sword
                    if event.key == pygame.K_RCTRL:
                        if p2.attack_timer <= 0:
                            sword = pygame.Rect(
                                p2.rect.left - 40,
                                p2.rect.y,
                                40,
                                p2.rect.height
                            )

                            # Check collision AND if P1 is not currently in i-frames
                            if sword.colliderect(p1.rect) and p1.i_frame == 0:
                                p1.health -= 20

                            p2.attack_timer = 20

                    # P1 rocket
                    if event.key == pygame.K_g:
                        rockets.append(
                            Rocket(
                                p1.rect.centerx,
                                p1.rect.centery,
                                8,
                                p1
                            )
                        )

                    # P2 rocket
                    if event.key == pygame.K_RSHIFT:
                        rockets.append(
                            Rocket(
                                p2.rect.centerx,
                                p2.rect.centery,
                                -8,
                                p2
                            )
                        )

                    # P1 Dodge Action
                    if event.key == p1.controls["dodge"]:
                        if p1.dodge_cooldown <= 0:
                            p1.i_frame = 15       # 15 frames of invincibility (~1/4 second according to chatgpt)
                            p1.dodge_cooldown = 45 # Cooldown before dodging again

                    # P2 Dodge Action
                    if event.key == p2.controls["dodge"]:
                        if p2.dodge_cooldown <= 0:
                            p2.i_frame = 15       # 15 frames of invincibility
                            p2.dodge_cooldown = 45 # Cooldown before dodging again

            elif game_state == GAME_OVER:

                if event.type == pygame.KEYDOWN:
                    game_state = MENU

        # =====================
        # UPDATE
        # =====================
        if game_state == PLAYING:

            keys = pygame.key.get_pressed()

            p1.update(keys)
            p2.update(keys)

            for rocket in rockets[:]:

                rocket.update()

                target = p2 if rocket.owner == p1 else p1

                if rocket.rect.colliderect(target.rect):
                    # Only take damage if the target is NOT dodging( Obviously)
                    if target.i_frame == 0:
                        target.health -= 25
                    rockets.remove(rocket)
                    continue

                if rocket.rect.x < 0 or rocket.rect.x > WIDTH:
                    rockets.remove(rocket)

            if p1.health <= 0:
                winner = "PLAYER 2 WINS!"
                game_state = GAME_OVER
                print("Player 2 won gng")

            if p2.health <= 0:
                winner = "PLAYER 1 WINS!"
                game_state = GAME_OVER
                print("HOW DO YOU LOSE AS Player 2")

        # =====================
        # DRAW GAME
        # =====================
        screen.fill((50, 50, 50))

        if game_state == MENU:

            text = font.render(
                "PRESS ANY KEY TO START",
                True,
                (255,255,255)
            )

            screen.blit(
                text,
                (WIDTH//2 - text.get_width()//2,
                 HEIGHT//2)
            )

        elif game_state == PLAYING:

            pygame.draw.rect(screen, (120,120,120),
                             (0, HEIGHT-50, WIDTH, 50))

            p1.draw()
            p2.draw()

            for rocket in rockets:
                rocket.draw()

            controls = controls_font.render(
                "P1: WASD [F]-Swd [G]-Rkt [E]-Ddg | P2: ARROWS [RCTRL]-Swd [RSHIFT]-Rkt [KP0]-Ddg",
                True,
                (255,255,255)
            )

            screen.blit(controls, (10,10))

        elif game_state == GAME_OVER:

            text = font.render(winner, True, (255,255,255))

            screen.blit(
                text,
                (WIDTH//2 - text.get_width()//2,
                 HEIGHT//2)
            )

            restart = font.render(
                "PRESS ANY KEY",
                True,
                (255,255,255)
            )

            screen.blit(
                restart,
                (WIDTH//2 - restart.get_width()//2,
                 HEIGHT//2 + 50)
            )

        pygame.display.flip()
        await asyncio.sleep(0)  # yields to the browser each frame (required by pygbag)

    pygame.quit()


asyncio.run(main())
